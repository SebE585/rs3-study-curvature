# RS3 — Étude de la courbure routière

Bienvenue sur la documentation du projet **RS3 Study Curvature**.
Ce site présente : 🚀

Découvrez tout ce qu'il faut savoir pour maîtriser l'analyse de la **courbure** et de la **pente** sur les réseaux routiers :

- 📐 la méthodologie de calcul de la **courbure** et de la **pente**,
- 🔍 la comparaison entre **BD TOPO®** et **OpenStreetMap**,
- 📊 les résultats **statistiques** et **visuels**,
- 📂 les jeux de données et la **reproductibilité**,
- 💼 une présentation produit (Elevator Speech + Business Model Canvas).

👉 Pour commencer : consultez la page **Produit** ([product.md](product.md)) pour le cadrage marché. Le *paper* sera publié ultérieurement.
