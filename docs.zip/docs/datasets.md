# 📚 Jeux de données

## BD TOPO® — Transport
Tronçons de route fournis par l'IGN.

## OpenStreetMap (OSM)
Données PBF pour la région Haute-Normandie, extraites avec pyrosm.

## MNT (RGE ALTI / Copernicus)
Données prévues pour l'analyse de la pente.

## Métadonnées
- **Millésimes**
- **Hash fichiers**
Pour plus de détails, voir [reproducibility.md](reproducibility.md).
