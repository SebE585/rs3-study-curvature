# Profils et classes de courbure

Analyse des profils moyens de courbure par classes (rayon, intensité du virage, etc.).

👉 Contenu à compléter avec figures et interprétations.
