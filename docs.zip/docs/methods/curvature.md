# Méthodes de calcul de la courbure

Présentation des différentes méthodes implémentées dans l’étude RS3 :
- dérivée des coordonnées
- ajustement par cercle
- interpolation par splines

👉 Contenu à compléter avec formules et exemples.
