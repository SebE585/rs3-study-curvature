# Courbure — Analyse des virages

Ce rapport se concentre sur les courbes détectées (séquences à forte courbure/faible rayon) et leur comparaison OSM vs BD TOPO.

## Indicateurs clés (KPIs)

_KPIs non trouvés — lancez `make curve-stats`._

## Figures

_Aucune figure détectée — lancez `make curve-profiles`._
