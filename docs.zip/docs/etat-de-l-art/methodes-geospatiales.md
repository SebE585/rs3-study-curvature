# Méthodes géospatiales

Description des méthodes utilisant des données GPS, SIG ou cartographiques (OSM, IGN, etc.).

👉 Contenu à compléter : sources de données, traitements, qualité attendue.
