# Modèles géométriques

Résumé des approches basées sur les modèles géométriques (arc de cercle, clothoïdes, splines…).

👉 Contenu à compléter : hypothèses, avantages, limites, références bibliographiques.
