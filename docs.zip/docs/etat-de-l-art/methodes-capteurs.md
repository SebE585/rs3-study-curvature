# Méthodes basées sur les capteurs

Résumé des approches reposant sur les capteurs embarqués (IMU, lidar, radar).

👉 Contenu à compléter : précision, fréquence, contraintes matérielles.
