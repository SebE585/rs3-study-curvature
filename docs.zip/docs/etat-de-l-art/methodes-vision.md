# Méthodes basées sur la vision

Présentation des techniques exploitant la vision par ordinateur (caméras embarquées, détection de bords, réseaux neuronaux).

👉 Contenu à compléter : pipeline type, benchmarks connus.
