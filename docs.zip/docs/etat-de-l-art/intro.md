# État de l’art — Introduction

Cette section introduit l’état de l’art sur l’estimation de la courbure routière.
Elle présente les grandes familles de méthodes et les domaines d’application associés.

👉 Contenu à compléter : contexte, problématique, revue générale.
