# Applications

Exemples d’applications de l’estimation de la courbure routière :
- ADAS (systèmes d’aide à la conduite)
- Conduite autonome
- Simulation réaliste
- Assurance et sécurité routière

👉 Contenu à compléter : cas d’usage détaillés et bénéfices.
