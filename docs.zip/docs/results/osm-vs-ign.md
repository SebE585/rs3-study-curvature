# Résultats — OSM vs IGN

Comparaison des courbures estimées à partir d’OpenStreetMap et des données IGN.
Mise en évidence des écarts de précision et de couverture.

👉 Contenu à compléter avec graphiques et statistiques.
