# Résultats — Distributions par classe

Distribution des rayons de courbure par classe de route (autoroutes, routes principales, secondaires, locales).

👉 Contenu à compléter avec histogrammes, boxplots, interprétations.
