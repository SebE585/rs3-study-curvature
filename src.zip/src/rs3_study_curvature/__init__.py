"""Curvature study package for RS3."""

__all__ = ["__version__"]
__version__ = "0.1.0"
